---
layout: page
title: About
sidebar_link: true
---

<p class="message">
  Hey there! This page is included as an example. Feel free to customize it
  for your own use upon downloading. Carry on!
</p>

To make pages show up in the sidebar, add `sidebar_link: true` to the front
matter.
---
layout: category
title: Edge Case
---

Sample category page. You need to create a page for each category.
The category is inferred from the title of the page, but you can also
specify it with the `category` attribute in the front matter.

```md
---
layout: category
title: My Category
---
```

|      |      |      |
| ---- | ---- | ---- |
|      |      |      |
|      |      |      |
|      |      |      |

```md
---
layout: category
title: My Category
---
```

Or ...

```md
---
layout: category
title: Fancy Title
category: My Category
---
```

Posts get listed below here.
